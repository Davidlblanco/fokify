// Global app controller
import num from "./test";
import david from "./david.js";
const x = 23;
console.log(`I imported ${num} from the module! variable x is ${x}`);